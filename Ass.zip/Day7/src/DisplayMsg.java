
public class DisplayMsg {

	public static void main(String[] args) {
		
		System.out.println("Display any Mesage");

	}

}
